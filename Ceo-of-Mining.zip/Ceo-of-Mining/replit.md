# Roadmap de Gestión Integral Minera

## Overview

This is an interactive mining management platform ("Roadmap de Gestión Minera") that transforms 8 management blocks into a visual, interactive roadmap. The system allows mining management teams, supervisors, auditors, and executives to track progress across all phases of the mining lifecycle with interactive checklists, evidence management, KPI dashboards, and stakeholder tracking.

The platform follows the philosophy of "Tolerar, Acompañar y Persistir" (Tolerate, Accompany, and Persist) as a guiding principle for mining operations management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query v5 for server state synchronization
- **UI Components**: Shadcn UI built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens supporting dark/light themes
- **Design System**: Material Design with Carbon Design influences for enterprise data-heavy context

The frontend follows a page-based architecture with 10 main views:
- Dashboard (roadmap overview)
- Bloques (8 management blocks)
- Block Detail (individual block with checklists)
- Contratos (contracts management)
- Stakeholders (internal/external stakeholder tracking)
- Evidencias (evidence and documentation)
- KPIs (performance metrics dashboard)
- Procedimientos (procedures and policies library)
- Accionistas (shareholder acceptance indicators)
- Demografico (demographic and social data)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Style**: RESTful endpoints under `/api/*`
- **Build Tool**: Vite for frontend, esbuild for server bundling

The server uses a clean separation between routes, storage interface, and database implementation. Routes validate input using Zod schemas derived from Drizzle table definitions.

### Data Layer
- **ORM**: Drizzle ORM with Zod schema validation
- **Database**: PostgreSQL via Neon serverless driver
- **Schema Location**: `shared/schema.ts` (shared between frontend and backend)

Core entities include:
- Blocks (8 management phases with progress tracking)
- Checklist Items (tasks per block with completion status)
- Evidences (documentation with status tracking)
- Stakeholders and Participation records
- KPIs (metrics with trends)
- Procedures (policies and normatives)
- Shareholder Metrics (acceptance indicators)
- Demographic Data (contextual social data)
- Contracts (with billing and status tracking)

### Path Aliases
- `@/*` → `./client/src/*`
- `@shared/*` → `./shared/*`
- `@assets/*` → `./attached_assets/*`

## External Dependencies

### Database
- **Neon PostgreSQL**: Serverless PostgreSQL database accessed via `@neondatabase/serverless` with WebSocket connections
- **Connection**: Requires `DATABASE_URL` environment variable

### UI Component Libraries
- **Radix UI**: Full suite of accessible primitives (dialog, dropdown, accordion, tabs, etc.)
- **Shadcn UI**: Pre-configured component layer with custom theming
- **Lucide React**: Icon library

### Data Management
- **TanStack Query**: Server state management with caching and synchronization
- **React Hook Form + Zod**: Form handling and validation

### Build Tools
- **Vite**: Frontend development server and bundler
- **Replit Plugins**: Runtime error overlay, cartographer, and dev banner for Replit environment