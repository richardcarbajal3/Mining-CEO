# Roadmap de Gestión Integral Minera

## Overview
Sistema interactivo de gestión integral minera que transforma 8 bloques en un roadmap visual e interactivo. Los usuarios pueden visualizar todas las fases, marcar tareas y evidencias como completadas, seguir el progreso por fase, contrato y stakeholder, y consultar políticas y procedimientos.

## Purpose
Proporcionar a equipos de gestión minera, supervisores, auditores y gerencias una herramienta completa para:
- Visualizar y gestionar los 8 bloques del ciclo de gestión minera
- Seguimiento de progreso con checklist interactivos
- Gestión de evidencias y documentación
- Monitoreo de KPIs y automatización
- Gestión de stakeholders y compromisos
- Acceso a procedimientos, políticas y normativas
- Indicadores de aceptación de accionistas
- Datos demográficos y sociales contextuales

## Current State
**Versión:** 1.0 (En desarrollo)
**Última actualización:** Octubre 11, 2025

### Funcionalidades Implementadas
- ✅ Dashboard principal con vista general del roadmap
- ✅ Sistema de navegación con sidebar
- ✅ Gestión completa de 8 bloques con estados (pendiente, en progreso, completado)
- ✅ Checklist interactivos por bloque con categorías
- ✅ Sistema de evidencias con estados y filtros
- ✅ Panel de stakeholders con participación por bloque
- ✅ Dashboard de KPIs con métricas de rendimiento
- ✅ Biblioteca de procedimientos y políticas con normativas
- ✅ Indicadores de aceptación de accionistas
- ✅ Panel social/demográfico con datos contextuales
- ✅ Filosofía "Tolerar, Acompañar y Persistir" destacada permanentemente
- ✅ Sistema de temas (Dark/Light mode)
- ✅ Diseño responsive y profesional

## Recent Changes
- **2025-10-11**: Implementación inicial del frontend completo
  - Creados todos los modelos de datos (bloques, checklist, evidencias, stakeholders, KPIs, procedimientos, métricas de accionistas, datos demográficos)
  - Implementadas 9 páginas principales con navegación completa
  - Configurado sistema de temas y diseño corporativo profesional
  - Agregado banner de filosofía persistente

## Project Architecture

### Frontend Stack
- **Framework:** React 18 con TypeScript
- **Routing:** Wouter
- **State Management:** TanStack Query v5
- **UI Components:** Shadcn UI + Radix UI
- **Styling:** Tailwind CSS con design tokens personalizados
- **Forms:** React Hook Form + Zod validation

### Backend Stack
- **Server:** Express.js
- **Storage:** In-memory storage (MemStorage)
- **Validation:** Zod schemas
- **API:** RESTful endpoints

### Design System
- **Primary Font:** Inter (sans-serif)
- **Monospace Font:** Roboto Mono (para datos y KPIs)
- **Color Scheme:** 
  - Primary: Professional mining blue (200 85% 45%)
  - Success/Completed: Green (142 76% 45%)
  - Warning/In-Progress: Amber (38 92% 50%)
  - Pending: Muted gray (220 15% 25%)
- **Default Theme:** Dark mode
- **Design Approach:** Enterprise Material Design con influencias de Carbon Design

### Data Models
1. **Blocks** - 8 bloques del roadmap minero
2. **ChecklistItems** - Tareas por bloque con categorías
3. **Evidences** - Documentos y evidencias por fase
4. **Stakeholders** - Actores internos y externos
5. **StakeholderParticipation** - Participación por bloque
6. **KPIs** - Indicadores de rendimiento
7. **Procedures** - Procedimientos y políticas
8. **ShareholderMetrics** - Métricas de accionistas
9. **DemographicData** - Datos sociales y demográficos

## File Structure
```
client/
  src/
    components/
      ui/ - Shadcn UI components
      app-sidebar.tsx - Navegación principal
      theme-provider.tsx - Gestión de temas
      theme-toggle.tsx - Toggle dark/light
      philosophy-banner.tsx - Banner de filosofía
    pages/
      dashboard.tsx - Vista principal roadmap
      bloques.tsx - Lista de bloques
      block-detail.tsx - Detalle de bloque con checklist y evidencias
      stakeholders.tsx - Gestión de stakeholders
      evidencias.tsx - Gestión de evidencias
      kpis.tsx - Dashboard de KPIs
      procedimientos.tsx - Procedimientos y políticas
      accionistas.tsx - Métricas de accionistas
      demografico.tsx - Datos demográficos
server/
  routes.ts - API endpoints
  storage.ts - Interface de almacenamiento
shared/
  schema.ts - Modelos de datos compartidos
```

## User Preferences
- Interfaz profesional y corporativa
- Visualización tipo roadmap interactivo
- Colores diferenciados por estado
- Experiencia motivadora centrada en acción
- Filosofía "Tolerar, Acompañar y Persistir" siempre visible

## Philosophy
**"Tolerar, Acompañar y Persistir"** es el principio fundamental que guía todas las operaciones y decisiones del proyecto minero. Este lema aparece de forma permanente en la interfaz para recordar los valores organizacionales.
